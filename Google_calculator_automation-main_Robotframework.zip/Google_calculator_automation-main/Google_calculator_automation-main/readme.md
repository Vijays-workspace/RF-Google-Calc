## Google calculator automation example

Small example for Google calculator automation, using Robot Framework and SeleniumLibrary

How to use:
Copy all files to same folder, execute command
"robot Web_calc_automation.robot"

Prerequisites
- Robot Framework 3.1.2
- SeleniumLibrary 3.141.0
